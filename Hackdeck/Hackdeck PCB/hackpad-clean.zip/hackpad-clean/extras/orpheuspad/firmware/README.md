# Firmware

Inside of here you'll find two folders:

**KMK:** This is a port of orpheuspad to KMK Firmware. Currently not done

**QMK:** This is a port of orpheuspad to QMK firmware. Very primitive setup currently, but it works!