#define ENCODER_A_PINS { GP2 }
#define ENCODER_B_PINS { GP1 }

// #define WS2812_DI_PIN GP3
// #define RGBLIGHT_LED_COUNT 2

// #define I2C_DRIVER I2CD1
// #define I2C1_SDA_PIN GP6
// #define I2C1_SCL_PIN GP7