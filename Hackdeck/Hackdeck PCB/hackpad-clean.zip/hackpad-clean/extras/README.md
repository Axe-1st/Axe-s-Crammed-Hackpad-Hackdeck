# Extras!

This is a folder of extra stuff that you may find useful. Inside are the following:

- kicad_care_package: this is a quick library starterpack for hackpad! It contains everything you need to make your first macropad. You can download a zipped version [here](https://github.com/hackclub/hackpad/releases)
- Knurled_Knob.step - this is a custom Hack Club branded rotary encoder I made!
- Orpheuspad - this is the the macropad I designed as an example! It contains one of every component, so you can use it as a reference to learn how to use different parts!