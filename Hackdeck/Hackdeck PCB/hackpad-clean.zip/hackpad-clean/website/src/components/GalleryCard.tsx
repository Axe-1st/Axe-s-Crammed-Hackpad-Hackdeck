const GalleryCard = () => {
    return <div>TBD!</div>;
};

export default GalleryCard;
